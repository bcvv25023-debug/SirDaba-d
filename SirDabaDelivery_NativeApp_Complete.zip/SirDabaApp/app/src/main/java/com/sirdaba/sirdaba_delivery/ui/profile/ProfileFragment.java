package com.sirdaba.sirdaba_delivery.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.onesignal.OneSignal;
import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.api.SirDabaRepository;
import com.sirdaba.sirdaba_delivery.ui.login.LoginActivity;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;

public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 64, 48, 48);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        // اسم المستخدم
        TextView tvName = new TextView(requireContext());
        tvName.setText(TokenManager.getUserName(requireContext()));
        tvName.setTextSize(20f);
        tvName.setTextColor(0xFF000000);
        tvName.setGravity(Gravity.CENTER);
        layout.addView(tvName);

        // البريد الإلكتروني
        TextView tvEmail = new TextView(requireContext());
        tvEmail.setText(TokenManager.getUserEmail(requireContext()));
        tvEmail.setTextSize(14f);
        tvEmail.setTextColor(0xFF757575);
        tvEmail.setGravity(Gravity.CENTER);
        tvEmail.setPadding(0, 8, 0, 0);
        layout.addView(tvEmail);

        // المدينة
        TextView tvCity = new TextView(requireContext());
        tvCity.setText("📍 " + TokenManager.getUserCity(requireContext()));
        tvCity.setTextSize(14f);
        tvCity.setTextColor(0xFF757575);
        tvCity.setGravity(Gravity.CENTER);
        tvCity.setPadding(0, 8, 0, 48);
        layout.addView(tvCity);

        // زر تسجيل الخروج
        Button btnLogout = new Button(requireContext());
        btnLogout.setText(R.string.logout);
        btnLogout.setBackgroundColor(0xFFFF6B35);
        btnLogout.setTextColor(0xFFFFFFFF);
        btnLogout.setOnClickListener(v -> performLogout());
        layout.addView(btnLogout);

        return layout;
    }

    private void performLogout() {
        SirDabaRepository repo = new SirDabaRepository(requireContext());
        repo.logout(new SirDabaRepository.Callback<>() {
            @Override public void onSuccess(Object data) {
                requireActivity().runOnUiThread(() -> {
                    OneSignal.logout();
                    TokenManager.clearAll(requireContext());
                    startActivity(new Intent(requireContext(), LoginActivity.class));
                    requireActivity().finish();
                });
            }
            @Override public void onError(String message) {
                onSuccess(null);
            }
        });
    }
}
